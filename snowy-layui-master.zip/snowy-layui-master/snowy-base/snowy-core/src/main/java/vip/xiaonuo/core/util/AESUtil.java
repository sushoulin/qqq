package vip.xiaonuo.core.util;



import oshi.SystemInfo;
import oshi.hardware.HardwareAbstractionLayer;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;


public class AESUtil {
    private static final String ALGORITHM = "AES";
    private static final int KEY_SIZE = 128;

    public static String encrypt(String data, String key){

        try {
            byte[] raw = key.getBytes("utf-8");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");//"算法/模式/补码方式"
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
            byte[] encrypted = cipher.doFinal(data.getBytes("utf-8"));
            return new BASE64Encoder().encode(encrypted);//此处使用BASE64做转码功能，同时能起到2次加密的作用。
        }catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String decrypt(String encryptedData, String key){
        try {
            byte[] raw = key.getBytes("utf-8");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            byte[] encrypted1 = new BASE64Decoder().decodeBuffer(encryptedData);//先用base64解密
            byte[] original = cipher.doFinal(encrypted1);
            String originalString = new String(original,"utf-8");
            return originalString;
        }catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String getMachineCode() {
        SystemInfo systemInfo = new SystemInfo();
        HardwareAbstractionLayer hardware = systemInfo.getHardware();
        String cpuId = hardware.getProcessor().getProcessorIdentifier().getProcessorID();
        String diskId = hardware.getComputerSystem().getSerialNumber().toString();

        return cpuId + diskId;
    }



    public static void main(String[] args) {
        try {
            System.out.println(getMachineCode());
//            System.out.println(new BASE64Encoder().encode("cptbtptp".getBytes()));
//            System.out.println(new String(new BASE64Decoder().decodeBuffer(new BASE64Encoder().encode("cptbtptp".getBytes())),"utf-8"));
//            String original = "Hello, World!";
//            String key = "Hello";
//            String encrypted = AESUtil.encrypt(original, key);
//            System.out.println("Encrypted: " + encrypted);
//            String decrypted = AESUtil.decrypt(encrypted, key);
//            System.out.println("Decrypted: " + decrypted);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
