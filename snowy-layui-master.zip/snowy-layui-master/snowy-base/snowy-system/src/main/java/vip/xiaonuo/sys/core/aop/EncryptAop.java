package vip.xiaonuo.sys.core.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import vip.xiaonuo.core.annotion.Encrypt;
import vip.xiaonuo.sys.modular.consts.service.SysConfigService;

import javax.servlet.http.HttpServletRequest;

@Aspect
@Component
public class EncryptAop {
    @Autowired
    private SysConfigService sysConfigService;

    @Before(value = "@annotation(encrypt)")
    public void boBefore(JoinPoint joinPoint, Encrypt encrypt) {
        sysConfigService.verifySign();
    }
}
