## _images 相关说明

1. 【snowy_layui_biz.png】          业务架构
2. 【snowy_layui_application.png】  应用架构
3. 【snowy_layui_data.png】         数据架构
4. 【snowy_layui_tech.png】         技术架构
5. 【snowy_layui_deploy.png】       部署架构

