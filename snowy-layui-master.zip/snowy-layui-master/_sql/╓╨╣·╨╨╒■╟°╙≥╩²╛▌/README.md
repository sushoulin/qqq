sys_area.sql[zip]: https://pan.xiaonuo.vip/#s/7rFnfuTA

sys_area_mssql.sql: https://pan.xiaonuo.vip/#s/65K_gwMA

sys_area_mssql.sql[zip]: https://pan.xiaonuo.vip/#s/7eINRsLA

sys_area_oracle.sql: https://pan.xiaonuo.vip/#s/65K_nkaQ

sys_area_oracle.sql[zip]: https://pan.xiaonuo.vip/#s/7eINrDlg

sys_area_postgresql.sql: https://pan.xiaonuo.vip/#s/65K_vyrg

sys_area_postgresql.sql[zip]: https://pan.xiaonuo.vip/#s/7eIX3g8w

sys_area_kingbase8_r3.dmp: https://pan.xiaonuo.vip/#s/65K_UJFQ